//inclusion des fichiers d'ent�tes 
#include <stdlib.h>
#include <stdio.h>

typedef unsigned char boolean;
typedef unsigned char byte;

int main() {
	//Declaration de variables
	char OneLetter = 'A';
	char AnOtherLetter = 66;
	byte toto = 0;
	unsigned char VerySmallCounter = 255;
	short smallCounter = 32767;
	int Counter = 0;
	long LargeCounter = 2147483647;
	unsigned long FullRangeLargeCounter = 4294967295;
	int ChienDeGarde = 0;
	float Dim1 = 1.414F;
	double Dim2 = .5L;
	boolean TestResult = 1;
	//Declaration de constante 
	const double Pi = 3.14159265L;
	//Declaration des variables A,B,C 
	int A, B, C;
	//initialisation
	A = 1;
	B = 2;
	C = 3;
	//Affichage des valeurs et des adresses m�moires
	printf("A: valeur=%d, adresse=%x\nB: valeur=%d, adresse=%x\nC: valeur=%d, adresse=%x\n", A, &A, B, &B, C, &C);
	/*
	 * On remarque que les 3 adresses sont cons�cutives. 
	*/

	//Les instructions du programme principal
	/**********     debut     ************/
	printf("\n");
	/* Affichage des deux chaines:
	 * OneLetter : s'affiche comme A
	 * AnOtherLetter : s'affiche comme B (60 correspond � B dans la table ascii)
	*/
	printf("exemple d'affichage d'un caractere %c, codage sur %d octets\n", OneLetter, sizeof(OneLetter));
	printf("exemple d'affichage d'un caractere %c, codage sur %d octets\n", AnOtherLetter, sizeof(AnOtherLetter));
	/* Affichage d'un byte *caract�re non sign�*
	 * toto : s'affiche comme 0
	 * VerySmallCounter : s'affiche comme 255;
	*/
	printf("exemple d'affichage d'un byte -caract�re non sign�- %u, codage sur %d octets\n", toto, sizeof(toto));
	printf("exemple d'affichage d'un caract�re non sign� %u, codage sur %d octets\n", VerySmallCounter, sizeof(VerySmallCounter));
	/* Affichage d'un entier court
	 * smallCounter : s'affiche comme 32767
	*/
	printf("exemple d'affichage d'un entier court %hd, codage sur %d octets\n", smallCounter, sizeof(smallCounter));
	/* Affichage d'un entier
	 * Counter : s'affiche comme 0
	*/
	printf("exemple d'affichage d'un entier %d, codage sur %d octets\n", Counter, sizeof(Counter));
	/* Affichage d'un entier long
	 * LargeCounter : s'affiche comme 2147483647
	*/
	printf("exemple d'affichage d'un entier long %ld, codage sur %d octets\n", LargeCounter, sizeof(LargeCounter));
	/* Affichage d'un entier long non sign�
	 * FullRangeLargeCounter : s'affiche comme 4294967295
	*/
	printf("exemple d'affichage d'un entier long non signe %lu, codage sur %d octets\n", FullRangeLargeCounter, sizeof(FullRangeLargeCounter));
	/* Affichage d'un r�el
	 * Dim1 : s'affiche comme 1.414000 (float)
	 * Dim2 : s'affiche comme 0.500000 (double)
	*/
	printf("exemple d'affichage d'un reel (float) %lf, codage sur %d octets\n", Dim1, sizeof(Dim1));
	printf("exemple d'affichage d'un reel (double) %f, codage sur %d octets\n", Dim2, sizeof(Dim2));
	/* Affichage d'un boolean
	 * TestResut : s'affiche comme 1
	*/
	printf("exemple d'affichage d'un boolean %u, codage sur %d octets\n", TestResult, sizeof(TestResult));
	/**********     fin     ************/
	system("pause");
	return(EXIT_SUCCESS);
}

/* Type          ***   Taille     ***       Valeur     ***       Valeur      ***     Natif?   ***       d�fini �
                      en octets    *         min        *         max         *                *       partir de:
 ***************************************************************************************************************************
 Char            ***       1       ***   -128          ***      127          ***       oui    ***           -
 byte            ***       1       ***     0           ***      255          ***       non    ***           unsigned char
 unsigned Char   ***       1       ***     0           ***      255          ***       oui    ***           -
 short int       ***       2       ***  -32768         ***    32767          ***       oui    ***           -
 int             ***       4       *** -2 147 483 648  *** 2 147 483 647     ***       oui    ***           -
 long            ***       4       ***     -           ***       -           ***       oui    ***           -
 unsigned long   ***       4       ***     -           ***       -           ***       oui    ***           - 
 float           ***       4       ***     -           ***       -           ***       oui    ***           -
 double          ***       8       ***     -           ***       -           ***       oui    ***           -
 */