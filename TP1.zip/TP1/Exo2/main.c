#include <stdio.h>
#include <math.h>

int main() {
	/*
	* Une boucle qui affiche tous les nombres compris entre 0 et 100 inclus
	*/
	int i = 0;
	printf("\nvaleur du compteur avant la premiere boucle: %d\n", i);
	for (i = 0; i <= 100; i++)
		printf("%d ", i);
	printf("\nvaleur du compteur apres la premiere boucle: %d\n", i);
	printf("fin du premier affichage\n");
	/*
	* Deux boucles imbriqu�es qui affichent les caract�re de la table ascii entre 32 et 127
	* en les r�partissant en six lignes de 16 caract�res
	*/
	int j = 32;
	printf("\nvaleur du compteur avant la deuxieme boucle: %d\n", j);
	while (j <= 127) {
		for (int k = 0; k < 16; k++) {
			printf("%c ", j);
			j++;
		}
		printf("\n");
	}
	printf("\nvaleur du compteur apres la deuxieme boucle: %d\n", j);
	printf("fin du second affichage\n");
	/*
	* Afficher la liste d�croissante des valeurs entres 0 et 20 avec un pas de 0.5
	*/
	float f = 20;
	printf("\nvaleur du compteur avant la troisieme boucle: %.1f\n", f);
	while (f >= 0 ) {
		printf("%.1f ", f);
		f = f - 0.5;
	}
	printf("\nvaleur du compteur apres la troisieme boucle: %.1f\n", f);
	printf("fin du troisieme affichage\n");
	/*
	** Afficher la table des sinus de 0 � 90 degr�s en ajoutant 10 degr�s � la fois
	** Pour utiliser la fonction sinus, on a besoin d'inclure le header math.h
	** La fonction fournie dans la biblioth�que standard de c permet de calculer le sinus 
	*  � partir d'un angle exprim� en radian, il faut donc convertir le degr� en radian
	*  en utilisant la formule radian = degre * pi / 180
	*/
	double pi = 3.1415926535;
	int angle_degre = 0;
	double angle_radian = 0;
	while (angle_degre <= 90) {
		angle_radian = angle_degre * pi / 180;
		printf("sin(%d)=%.2lf\n", angle_degre, sin(angle_radian));
		angle_degre = angle_degre + 10;
	}
}